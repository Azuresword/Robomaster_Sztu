
#ifndef RMC_CODE_DEGCYCLEPID_H
#define RMC_CODE_DEGCYCLEPID_H

#include "struct_typedef.h"

void MotorSetDeg(float Deg);

#endif //RMC_CODE_DEGCYCLEPID_H
