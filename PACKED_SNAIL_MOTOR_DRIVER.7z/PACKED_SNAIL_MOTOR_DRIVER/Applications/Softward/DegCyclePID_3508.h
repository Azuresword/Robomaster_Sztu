
#ifndef RMC_CODE_DEGCYCLEPID_3508_H
#define RMC_CODE_DEGCYCLEPID_3508_H

#include "struct_typedef.h"

void MotorSetDeg_3508(float Deg);

#endif //RMC_CODE_DEGCYCLEPID_3508_H
